package selenium;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

import driver.driver;
public class selenium extends driver{
public void abrir() {
	System.setProperty("webdriver.chrome.driver","driver/chromedriver.exe");
	driver= new ChromeDriver();
}
public void abrirpagina() {
	driver.get("https://www.phptravels.net/login");
	driver.manage().window().maximize();
}
public void seleccionarelhotel() throws InterruptedException, AWTException {
	Thread.sleep(5000);
	WebElement emaill= driver.findElement(By.xpath("//input[@name='email']"));
	emaill.click();
	emaill.sendKeys("user@phptravels.com");
	WebElement password= driver.findElement(By.xpath("//input[@name='password']"));
	password.click();
	password.sendKeys("demouser");
	WebElement botonl= driver.findElement(By.xpath("//button[@type='submit']"));
	botonl.click();
	Thread.sleep(5000);
	WebElement botonl1= driver.findElement(By.xpath("/html/body/header/div[2]/div/div/div/div/div[2]/nav/ul/li[2]/a"));
	botonl1.click();
	WebElement bus= driver.findElement(By.xpath("//span[@id='select2-hotels_city-container']"));
	bus.click();
	WebElement bus1= driver.findElement(By.xpath("/html/body/span/span/span[1]/input"));
	bus1.sendKeys("singa");
	Robot robot = new Robot();
    robot.mouseMove(200, 470);
    Thread.sleep(5000);
    robot.mousePress(InputEvent.BUTTON1_MASK);
    robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
    WebElement check= driver.findElement(By.xpath("/html/body/section[1]/section/div/div/form/div/div/div[2]/div/div[1]/div/input"));
	check.click();
	WebElement check1= driver.findElement(By.xpath("/html/body/div[3]/div[1]/table/thead/tr[1]/th[3]/i"));
	check1.click();
	WebElement check2= driver.findElement(By.xpath("/html/body/div[3]/div[1]/table/thead/tr[1]/th[3]/i"));
	check2.click();
	WebElement check3= driver.findElement(By.xpath("/html/body/div[3]/div[1]/table/thead/tr[1]/th[3]/i"));
	check3.click();
	WebElement check4= driver.findElement(By.xpath("/html/body/div[3]/div[1]/table/tbody/tr[5]/td[5]"));
	check4.click();
	WebElement chec1= driver.findElement(By.xpath("/html/body/div[4]/div[1]/table/thead/tr[1]/th[3]/i"));
	chec1.click();
	WebElement chec2= driver.findElement(By.xpath("/html/body/div[4]/div[1]/table/thead/tr[1]/th[3]/i"));
	chec2.click();
	WebElement chec3= driver.findElement(By.xpath("/html/body/div[4]/div[1]/table/thead/tr[1]/th[3]/i"));
	chec3.click();
	WebElement chec4= driver.findElement(By.xpath("/html/body/div[4]/div[1]/table/thead/tr[1]/th[3]/i"));
	chec4.click();
	WebElement chec5= driver.findElement(By.xpath("/html/body/div[4]/div[1]/table/tbody/tr[3]/td[3]"));
	chec5.click();
	WebElement buscar= driver.findElement(By.xpath("//*[@id=\"submit\"]"));
	buscar.click();
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,250)", "");
	Thread.sleep(5000);
	WebElement correo= driver.findElement(By.xpath("/html/body/section[2]/div/div/div[2]/section/ul/li[2]/div/div[2]/div/div[2]/div/a/span[1]"));
	correo.click();
	Thread.sleep(2000);
	js.executeScript("window.scrollBy(0,250)", "");
	Thread.sleep(2000);
	js.executeScript("window.scrollBy(0,250)", "");
	Thread.sleep(2000);
	js.executeScript("window.scrollBy(0,250)", "");
}
public void terminarlareserva() throws InterruptedException {
	Thread.sleep(2000);
	WebElement booking= driver.findElement(By.xpath("/html/body/section[1]/div[3]/div/div/div/div/div[2]/div[2]/div[1]/div[2]/div/div[2]/form/div/div[4]/div/div/button"));
	booking.click();
	Thread.sleep(2000);
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,250)", "");
	Thread.sleep(2000);
	js.executeScript("window.scrollBy(0,250)", "");
	WebElement pn= driver.findElement(By.xpath("/html/body/div[2]/form/section/div/div/div[1]/div[2]/div[2]/div[1]/div[2]/div/div[2]/input"));
	pn.sendKeys("Javier");
	WebElement pa= driver.findElement(By.xpath("/html/body/div[2]/form/section/div/div/div[1]/div[2]/div[2]/div[1]/div[2]/div/div[3]/input"));
	pa.sendKeys("Castillo");
	Thread.sleep(2000);
	WebElement pn2= driver.findElement(By.xpath("/html/body/div[2]/form/section/div/div/div[1]/div[2]/div[2]/div[2]/div[2]/div/div[2]/input"));
	pn2.sendKeys("Hazel");
	WebElement pa2= driver.findElement(By.xpath("/html/body/div[2]/form/section/div/div/div[1]/div[2]/div[2]/div[2]/div[2]/div/div[3]/input"));
	pa2.sendKeys("Sierra");
	Select Miss = new Select (driver.findElement(By.xpath("/html/body/div[2]/form/section/div/div/div[1]/div[2]/div[2]/div[2]/div[2]/div/div[1]/select")));
	Miss.selectByIndex(1);
	Thread.sleep(2000);
	js.executeScript("window.scrollBy(0,250)", "");
	Thread.sleep(2000);
	js.executeScript("window.scrollBy(0,250)", "");
	WebElement pay= driver.findElement(By.xpath("/html/body/div[2]/form/section/div/div/div[1]/div[3]/div[2]/div/ul/label/label/label/label/div/div/div[1]/input"));
	pay.click();
	Thread.sleep(2000);
	js.executeScript("window.scrollBy(0,250)", "");
	Thread.sleep(2000);
	WebElement tyc= driver.findElement(By.xpath("//body[@id='fadein']/div[2]/form/section/div/div/div/div[4]/div/div/div/label"));
	tyc.click();
	Thread.sleep(2000);
	WebElement cbo= driver.findElement(By.xpath("/html/body/div[2]/form/section/div/div/div[1]/div[5]/div/button"));
	cbo.click();
	Thread.sleep(2000);
	WebElement mac= driver.findElement(By.xpath("/html/body/header/div[1]/div/div/div[2]/div/div/div[3]/div/button"));
	mac.click();
	Thread.sleep(2000);
	WebElement mac1= driver.findElement(By.xpath("/html/body/header/div[1]/div/div/div[2]/div/div/div[3]/div/ul/li[2]/a"));
	mac1.click();
}
}

