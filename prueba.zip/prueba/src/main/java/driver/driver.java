package driver;
import org.openqa.selenium.*;
public class driver {
public static WebDriver driver;
}
